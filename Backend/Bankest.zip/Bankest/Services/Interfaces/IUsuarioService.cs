﻿using Bankest.DTOs;
using Bankest.Models;

namespace Bankest.Services.Interfaces
{
    public interface IUsuarioService
    {
        //Task<LoginResponseDto> GetUsuarioByPassword(LoginResponseDto user);
    }
}
