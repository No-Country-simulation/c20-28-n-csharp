﻿namespace Bankest.DTOs
{
    public class LoginResponseDto
    {
        public string Token {  get; set; }
        public string Response { get; set; }
    }
}
